#include <iostream>
#include <ctime>
using namespace std;

void wyswietl(int tab[], int wielkosc);
void wyswietl(double tab[], int wielkosc);
void zad1(int tab[], int wielkosc);
void zad2(unsigned int n, int tab[]);
void zad3(double tab1[], double tab2[], double tab3[], int wielkosc);
void zad4();
void zad5(int tab[], int n);

int main() {
    //  definicja wielkosci tablicy
    const unsigned int n = 10;


    int tab[n];
    int tab_5[n];
    double tab1[n] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}, tab2[n] = {11, 12, 13, 14, 15, 16, 17, 18, 19, 110}, tab3[2 * n];
    srand(time(0));

    //  Poszczegolne zadania
    /*zad1(tab, n);
    zad2(n, tab);
    zad3(tab1, tab2, tab3, n);
    */
    
    zad4();
    //zad5(tab_5, n);
    return 0;
}


void zad1(int tab[], int n) {
    int i;

    //  Kolejne podpunkty zadania
    wyswietl(tab, n);

    for (i = 0; i < n; i++)
        tab[i] = 0;
    wyswietl(tab, n);

    for(i = 0; i < n; i++)
        tab[i] = i;
    wyswietl(tab, n);

    for(i = 0; i < n; i++)
        tab[i] *= 2;
    wyswietl(tab, n);

    for(i = 0; i < n; i++)
        tab[i] += n * n;
    wyswietl(tab, n);
    cout << endl;
}

void zad2(unsigned int n, int tab[]) {
    int a, b;
    for(int i = n - 1; i >= 0; i--) {
        if(i == n - 1) {
            a = tab[i];
            tab[i] = tab[0];
        }
        else {
            b = tab[i];
            tab[i] = a;
            a = b;
        }
    }
    wyswietl(tab, n);
    cout << endl;
}

void zad3(double tab1[], double tab2[], double tab3[], int wielkosc) {
    int a = 0, b = 0;
    for(int i = 0; i < 2 * wielkosc; i++) {
        if(i % 2 == 0) {
                tab3[i] = tab2[a];
                a++;
        }
        else {
            tab3[i] = tab1[b];
            b++;
        }
    }

    wyswietl(tab1, wielkosc);
    wyswietl(tab2, wielkosc);
    wyswietl(tab3, wielkosc * 2);
    cout << endl;
}

void zad4() {
    int i, k, skalar;
    int a[3], b[3];
    //  Odczyt
    cout << "wektor a:\n";
    for(i = 0; i < 3; i++) {
        cout << "Podaj wymiar " << i + 1 << " ";
        cin >> a[i];
    }

    cout << "wektor b:\n";
    for(i = 0; i < 3; i++) {
            cout << "Podaj wymiar " << i + 1 << " ";
            cin >> b[i];
    }

    skalar = a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
    cout << "skalar = " << skalar << endl;
    if(skalar == 0) cout << "Wektory prostopadle";
}

void zad5(int tab[], int n) {
    char d;
    int i, j, k, suma, maks[n] = {};
    do {
        cout << "-------------------------------------\n";
        cout << "Aktualny rozmiar tablicy: " << n << endl;
        cout << "a Wprowadzenie kolejnych warto�ci do tablicy przez uzytkownika\n";
        cout << "b Automatyczne uzupelnienie tablicy liczbami naturalnymi\n";
        cout << "c uzupelenienie losowymi liczbami\n";
        cout << "d suma elementow tablicy\n";
        cout << "e najwiekszy element i jego indeks\n";
        cout << "f wyswietlenie elementow tablicy\n";
        cout << "g wyjscie\n";
        cin >> d;
        switch (d) {
        case 'a':
            for (i = 0; i < n; i++) {
                cout << "Podaj wartosci nr " << i << ": ";
                cin >> tab[i];
            }
            cout << "Uzupelniono";
            break;
        case 'b':
            for (i = 0; i < n; i++)
                tab[i] = i + 1;
            cout << "Uzupelniono";
            break;
        case 'c':
            cout << "Podaj dolny zakres liczb: ";
            cin >> j;
            cout << "Podaj gorny zakres: ";
            cin >> k;
            for (i = 0; i < n; i++)
                tab[i] = rand() % (k - j + 1) + j;
            cout << "Uzupelniono\n";
            break;
        case 'd':
            suma = 0;
            for (i = 0; i < n; i++)
                suma += tab[i];
            cout << "Suma elementow tablicy: " << suma;
            break;
        case 'e':
            j = 1;
            suma = tab[0];
            maks[0] = j;
            for (i = 1; i < n; i++) {
                if (tab[i] >= suma) {
                    if (tab[i] != suma) j++;
                    suma = tab[i];
                    maks[i] = j;
                }
            }
            cout << "Najwiekszy element: " << suma << endl;
            cout << "Indeks/y elementu/ow: ";
            for (i = 0; i < n; i++) {
                if (maks[i] == j) cout << i << ", ";
            }
            break;
        case 'f':
            for (i = 0; i < n; i++)
                cout << "tab[" << i << "] = " << tab[i] << endl;
            break;
        default:
            break;
        }
        cout << endl;
    } while (d != 'g');
}

void wyswietl(int tab[], int wielkosc) {
    for(int i = 0; i < wielkosc; i++)
        cout << tab[i] << "\t";
    cout << endl;
}

void wyswietl(double tab[], int wielkosc) {
    for(int i = 0; i < wielkosc; i++)
        cout << tab[i] << "\t";
    cout << endl;
}
