#include <iostream>
#include <fstream>
using namespace std;

int main() {
    //  Otwarcie plikow
    ifstream odczyt("dane_wej_1.txt");
    ofstream wyniki("wyniki.txt");
    float a, b, buff;
    int ile, seria = 1, d = 1, prawidlowe;
    if(odczyt.good()) cout << "Plik otwarty pomyslnie" << endl;

    while(d) {
        a = 0;
        b = 0;
        ile = 0;
        for(int prawidlowe = 0; prawidlowe < 99; ) {
            odczyt >> a;
            //  sprawdzanie czy nalezy do zakresu
            if(a < -10 || a > 10) {
                    if(a == 99) {
                        wyniki << "Koniec rejestru";
                        d = 0;
                        break;
                    }
            }
            else {
                prawidlowe++;
                if (prawidlowe != 99) {
                    if (a * b < 0) ile++;
                    odczyt >> buff;
                    //  Pomijanie zer
                    if (buff != 0) if (buff > -10 && buff < 10) {
                        b = buff;
                        prawidlowe++;
                        if (a * b < 0) ile++;
                    }
                }
            }
        }

        //  Wysylanie wynikow do pliku
        if (d) {
            wyniki << "Seria nr " << seria << endl;
            wyniki << "Przeciecia: " << ile << endl;
            wyniki << "Puls: " << ile * 6 << endl;
            if(ile <= 8 || ile >= 14) wyniki << "Puls nieprawidlowy" << endl;
            wyniki << endl;
            seria++;
        }
    }

    //  Zamykanie plikow
    odczyt.close();
    wyniki.close();
    return 0;
}
