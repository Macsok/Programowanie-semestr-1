#include <iostream>
using namespace std;

struct samochod {
	string marka;
	string model;
	float pojemnosc;
	float predkosc_maks;
	samochod* nastepny;
};

samochod* dodaj_element(samochod* lista);
void wyswietl(samochod* lista);
void wyswietl(samochod* lista, int p);
samochod* usun_elementy(samochod* lista);

int main() {
	samochod* lista_aut = new samochod;
	lista_aut = NULL;
	string str;
	int dec;
	//	Menu
	do {
		cout << "1 dodaj\n2 wyswietl wszystkie\n3 wyswietl po id\n4 usun\n0 wyjscie\n";
		cin >> dec;
		switch (dec) {
		case 1:
			lista_aut = dodaj_element(lista_aut);
			break;
		case 2:
			wyswietl(lista_aut);
			break;
		case 3:
			cout << "Ktory samochod wyswietlic (id od 1): ";
			cin >> dec;
			wyswietl(lista_aut, dec);
			break;
		case 4:
			lista_aut = usun_elementy(lista_aut);
			break;
		default:
			dec = 0;
			break;
		}
		cout << endl;
	} while (dec);

	delete lista_aut;
	return 0;
}

//	Dodawanie elementu do listy
samochod* dodaj_element(samochod* lista) {
	samochod* nowy = new samochod;
	string str;
	cout << "Marka: ";
	cin >> nowy->marka;
	cout << "Model: ";
	cin >> nowy->model;
	cout << "Pojemnosc: ";
	cin >> nowy->pojemnosc;
	cout << "Predkosc maks.: ";
	cin >> nowy->predkosc_maks;
	nowy->nastepny = lista;
	return nowy;
}

//	Wyswietlanie calej listy
void wyswietl(samochod* lista) {
	if (!lista) cout << "Lista pusta\n";
	while (lista) {
		cout << lista->marka << " - " << lista->model << " - " << lista->pojemnosc << " - " << lista->predkosc_maks << endl;
		lista = lista->nastepny;
	}
}

//	Wyswietlanie danego elementu
void wyswietl(samochod* lista, int p) {
	for (int i = 1; i < p; i++) {
		if (lista == NULL) {
			cout << "Brak rejestru\n";
			break;
		}
		lista = lista->nastepny;
	}
	if (lista != NULL) cout << lista->marka << " - " << lista->model << " - " << lista->pojemnosc << " - " << lista->predkosc_maks << endl;
}

//	Usuwanie elementow
samochod* usun_elementy(samochod* lista) {
	string _marka, _model;
	float _poj, _pr;
	//	Pobranie kryteriow
	cout << "Podaj kryteria pojazdow do usuniecia (0 jesli nie dotyczy):\nMarka: ";
	cin >> _marka;
	cout << "Model: ";
	cin >> _model;
	cout << "Pojemnosc: ";
	cin >> _poj;
	cout << "Predkosc: ";
	cin >> _pr;

	samochod* glowa = lista;
	samochod* ogon, *poprzedni = lista;
	int ile = 0;
	//	odczytanie dlugosci listy
	while (lista) {
		ile++;
		ogon = lista;
		lista = lista->nastepny;
	}
	lista = glowa;
	//	WLasciwe usuwanie
	for (int i = 0; i < ile; i++) {
		if (lista->marka == _marka || lista->model == _model || lista->pojemnosc == _poj || lista->predkosc_maks == _pr) {
			//	Usun pierwsze
			if (lista == glowa) {
				if (glowa == ogon) return NULL;
				else {
					glowa = lista->nastepny;
				}
			}
			//	Usun srodkowe
			else if(lista != ogon) {
				poprzedni->nastepny = lista->nastepny;
			}
			//	Usun ogon
			else {
				poprzedni->nastepny = NULL;
			}
		}
		//	przypisanie poprzedniego
		poprzedni = lista;
		//	przesuniecie na kolejny element
		lista = lista->nastepny;
	}
	return glowa;
}