#include <iostream>
using namespace std;

int silnia(int n) {
    for(int i = n - 1; i > 1; i--) {
        n = n * i;
    }
    return n;
}

int main() {
    unsigned int n;
    do {
        cout << "Podaj nieujemna liczbe: ";
        cin >> n;
    } while(n < 0);
    cout << silnia(n);
    return 0;
}
