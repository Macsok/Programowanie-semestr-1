#include <iostream>
using namespace std;

unsigned int fib(int nth) {
    if(nth == 0) return 0;
    else if(nth == 1) return 1;
    else return fib(nth - 1) + fib(nth - 2);
}

int main() {
    unsigned int n;
    do {
        cout << "Podaj nieujemna liczbe: ";
        cin >> n;
    } while(n < 0);
    cout << fib(n);
    return 0;
}
