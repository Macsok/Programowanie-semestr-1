#include <iostream>
using namespace std;

int main() {
    int n, sum = 0;
    do {
        cout << "Podaj liczbe do dodania: ";
        cin >> n;
        if(n <= 15 && n >= -15)
            sum += n;
    } while(n != 99);
    cout << "Suma wynosi: " << sum;
    return 0;
}
