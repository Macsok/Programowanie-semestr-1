#include <iostream>
using namespace std;

unsigned int q_sum(int n) {
    unsigned int sum = 0;
    for(int i = 0; i <= n; i++)
        sum = sum + (i * i);
        return sum;
}

int main() {
    unsigned int n;
    do {
        cout << "Podaj nieujemna liczbe: ";
        cin >> n;
    } while(n < 0);
    cout << q_sum(n);
    return 0;
}
