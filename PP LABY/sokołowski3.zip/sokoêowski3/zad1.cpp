#include <iostream>
using namespace std;

int main() {
    unsigned int m, n, i = 1;
    do {
        cout << "Podaj pierwsza liczbe: ";
        cin >> n;
        cout << "Podaj druga liczbe: ";
        cin >> m;
    } while(n < 0 && m < 0);
    cout << "Wielokrotnosci pierwszej liczby < drugiej liczby:\n";
    while(n * i < m) {
        cout << n * i << endl;
        i++;
    }
    return 0;
}
