#include <iostream>
using namespace std;

void wielokrotnosci();
int silnia(int n);
int get_unsigned();
unsigned int q_sum(int n);
unsigned int fib(int nth);
void menu();

int main() {
    menu();
    return 0;
}

unsigned int fib(int nth) {
    if(nth == 0) return 0;
    else if(nth == 1) return 1;
    else return fib(nth - 1) + fib(nth - 2);
}
unsigned int q_sum(int n) {
    unsigned int sum = 0;
    for(int i = 0; i <= n; i++)
        sum = sum + (i * i);
        return sum;
}

int get_unsigned() {
    unsigned int n;
    do {
        cout << "Podaj nieujemna liczbe: ";
        cin >> n;
    } while(n < 0);
    return n;
}

int silnia(int n) {
    for(int i = n - 1; i > 1; i--) {
        n = n * i;
    }
    return n;
}

void wielokrotnosci() {
    unsigned int m, n, i = 1;
    do {
        cout << "Podaj pierwsza liczbe: ";
        cin >> n;
        cout << "Podaj druga liczbe: ";
        cin >> m;
    } while(n < 0 && m < 0);
    cout << "Wielokrotnosci pierwszej liczby < drugiej liczby:\n";
    while(n * i < m) {
        cout << n * i << endl;
        i++;
    }
}

void menu() {
    int n, w;
    do {
    cout << "\nWybierz jedno z polecen:\n";
    cout << "1  Wielokrotnosci\n";
    cout << "2  Silnia\n";
    cout << "3  Suma kwadratow\n";
    cout << "4  Element ciagu fibonacciego\n";
    cout << "5  Wyjscie\n";
    cin >> w;
    switch (w) {
    case 1:
        wielokrotnosci();
        break;
    case 2:
        n = get_unsigned();
        cout << n <<"! = " << silnia(n);
        break;
    case 3:
        n = get_unsigned();
        cout << "Suma wynosi: " << q_sum(n);
        break;
    case 4:
        n = get_unsigned();
        cout << "N-ty element ciagu: " << fib(n);
        break;
    default:
        break;
    }
    } while(w != 5);
}

