#include <iostream>
using namespace std;

void piramida(int n) {
    int i, k;
    for(i = 1; i <= n; i++) {
        for(k = 0; k < n-i; k++)
            cout << " ";
        for(k = 0; k < i; k++)
            cout << i << " ";
        cout << endl;
    }
}

int main() {
    unsigned int n;
    do {
        cout << "Podaj liczbe wierszy(>0): ";
        cin >> n;
    } while(n < 1);
    piramida(n);
    return 0;
}
