#include <iostream>
using namespace std;

int main() {
	//	Dynamiczna alokacja dwoch wektorow
	float* u = new float[2];
	float* v = new float[2];

	//	Pobranie wektorow
	cout << "wektor u[x,y]\nx = ";
	cin >> u[0];
	cout << "y = ";
	cin >> u[1];
	cout << "wektor v[x,y]\nx = ";
	cin >> v[0];
	cout << "y = ";
	cin >> v[1];

	//	Iloczyn skalarny
	float iloczyn;
	iloczyn = (u[0] * v[0]) + (u[1] * v[1]);
	cout << "Iloczyn skalarny wynosi: " << iloczyn;
	if (!iloczyn) cout << "\nWektory sa prostopadle";

	//	Zwolnienie pamieci
	delete[] u;
	delete[]v;
	return 0;
}