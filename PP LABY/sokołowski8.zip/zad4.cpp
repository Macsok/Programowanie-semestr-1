#include <iostream>
using namespace std;

int main() {
	int N = 4;
	int I = 0;
	int i;
	//	Alokacja tablicy deynamicznej
	int* tab = new int[N];

	//	Menu
	int decision;
	do {
		cout << "------------------------------------------\n";
		cout << "1 dodaj\n2 usun\n3 wyswietl\n0 wyjdz\n";
		cin >> decision;
		switch (decision) {
		case 1:
			//	Dodawanie
			if (N == I) {
				// Kopiowanie i tworzenie wiekszej tablicy
				int* kopia = new int[N];
				for (i = 0; i < N; i++) kopia[i] = tab[i];
				delete[] tab;
				tab = new int[N * 2];
				for (i = 0; i < N; i++) tab[i] = kopia[i];
				delete[] kopia;
				N = N * 2;
			}
			//	Wczytanie liczby
		
			cout << "Podaj liczbe: ";
			cin >> tab[I];
			I++;
			break;

		case 2:
			cout << "Ktory element usunac?";
			cin >> i;
			//	+1 bo numeruje usuwany element od 1
			i++;
			//	Zsuniecie
			for (int k = 0; k < N - 1; k++) if (k >= i) tab[k] = tab[k + 1];
			//	Przesuniecie iteratora
			I--;
			//	Zmniejszenie tablicy w skrajnym przypadku
			if (I == N / 2) {
				//	Aktualizacja wielkosci
				N = N / 2;
				int* kopia = new int[N];
				for (i = 0; i < N; i++) kopia[i] = tab[i];
				delete[] tab;
				tab = new int[N];
				for (i = 0; i < N; i++) tab[i] = kopia[i];
				delete[] kopia;
			}
			break;

		//	Wyswietlanie
		case 3:
			cout << "Tablica zapelniona " << I << " na " << N << endl;
			for (i = 0; i < I; i++) cout << "[" << i + 1 << "] = " << tab[i] << endl;
			break;

		default:
			decision = 0;
			break;
		}

		cout << "\nAktualnie elementow: " << I << " (dostepnych: " << N << ")\n";
		cout << endl;
	} while (decision);
	
	delete[] tab;
	tab = NULL;
	return 0;
}