#include <iostream>
#include <ctime>
using namespace std;

int main() {
    //  Losowy czas
    srand(time(0));
    int n;
    cout << "Podaj wymiar: ";
    cin >> n;
    //  Dynamiczne utworzenie tablicy
    int *tab = new int[n];
    for(int i = 0; i < n; i++) {
        tab[i] = rand()%51;
        cout << tab[i] << " ";
        if(!(tab[i] % 2)) tab[i] = 1;
        else tab[i] = 0;
    }
    cout << endl;

    //  Wyswietlenie
    for(int i = 0; i < n; i++)
        cout << tab[i] << " ";
    delete[] tab;
    return 0;
}
