#include<iostream>
using namespace std;

int rozmiar_1, rozmiar_2;

//
//
//      Kod zadania nr 5 jest takze rozwiazaniem zadania nr 1
// 
//

void menu();
void wprowadzenie(double** a, double** b);
void wyswietl(double** a, double** b);
void dodawanie(double** a, double** b);
void odejmowanie(double** a, double** b);
void mnozenie(double** a, double** b);
void transponowanie(double** a, double** b);

int main() {
    menu();
    return 0;
}

void menu() {
    char c;
    //  Ustalenie wymiarow
    cout << "Podaj liczbe wierszy macierzy: ";
    cin >> rozmiar_1;
    cout << "Podaj liczbe kolumn macierzy: ";
    cin >> rozmiar_2;
    //  Tworzenie tablic dwuwymiarowych
    double **A, **B;
    int i;
    A = new double* [rozmiar_1];
    B = new double* [rozmiar_1];
    for(i = 0; i < rozmiar_1; i++) {
        A[i] = new double[rozmiar_2];
        B[i] = new double[rozmiar_2];
    }
    //  Menu
    do {
        cout << "Wybierz opcje:\n";
        cout << "(a) wprowadzanie macierzy przez uzytkownika\n";
        cout << "(b) dodawanie macierzy\n";
        cout << "(c) odejmowanie macierzy\n";
        cout << "(d) mnozenie macierzy przez skalar\n";
        cout << "(e) transponowanie macierzy\n";
        cout << "(f) wyswietl\n";
        cout << "(q) wyjscie\n";
        cin >> c;
        switch (c) {
        case 'a':
            wprowadzenie(A, B);
            break;
        case 'b':
            dodawanie(A, B);
            break;
        case 'c':
            odejmowanie(A, B);
            break;
        case 'd':
            mnozenie(A, B);
            break;
        case 'e':
            transponowanie(A, B);
            break;
        case 'f':
            wyswietl(A, B);
            break;
        default:
            c = 'q';
            break;
        }
    }   while(c != 'q');
    //  Zwolnienie pamieci
    for(i = 0; i < rozmiar_1; i++) {
        delete[] A[i];
        delete[] B[i];
    }
    delete[] A;
    delete[] B;
}

void wprowadzenie(double** a, double** b) {
    //  Pobranie A
    for(int i = 0; i < rozmiar_1; i++)
        for(int j = 0; j < rozmiar_2; j++) {
            cout << "A[" << i + 1 << "][" << j + 1 << "] = ";
            cin >> a[i][j];
        }
    cout << endl;
    //  Pobranie B
    for(int i = 0; i < rozmiar_1; i++)
        for(int j = 0; j < rozmiar_2; j++) {
            cout << "B[" << i + 1 << "][" << j + 1 << "] = ";
            cin >> b[i][j];
        }
}

//  Wyswietlanie zapisanych macierzy
void wyswietl(double** a, double** b) {
    cout << "A\n\n";
    for(int i = 0; i < rozmiar_1; i++) {
        for(int j = 0; j < rozmiar_2; j++)
            cout << a[i][j] << " ";
        cout << endl;
    }
    cout << endl;
    cout << "B\n\n";
    for(int i = 0; i < rozmiar_1; i++) {
        for(int j = 0; j < rozmiar_2; j++)
            cout << b[i][j] << " ";
        cout << endl;
    }
    cout << endl;
}

void dodawanie(double** a, double** b) {
    cout << "Wynik dodawania A + B\n\n";
    for(int i = 0; i < rozmiar_1; i++) {
        for(int j = 0; j < rozmiar_2; j++)
            cout << a[i][j] + b[i][j] << " ";
        cout << endl;
    }
    cout << endl;
}

void odejmowanie(double** a, double** b) {
    cout << "Wynik odejmowania A - B\n\n";
    for(int i = 0; i < rozmiar_1; i++) {
        for(int j = 0; j < rozmiar_2; j++)
            cout << a[i][j] - b[i][j] << " ";
        cout << endl;
    }
    cout << endl;
}

//  Mnozenie przez skalar kazdego elementu, wyswietlenie
void mnozenie(double** a, double** b) {
    double n;
    cout << "Przez co chcesz pomnozyc macierze? ";
    cin >> n;
    cout << "Wynik mnozenia " << n << " * A\n\n";
    for(int i = 0; i < rozmiar_1; i++) {
        for(int j = 0; j < rozmiar_2; j++)
            cout << a[i][j] * n << " ";
        cout << endl;
    }
    cout << endl;
    cout << "Wynik mnozenia " << n << " * B\n\n";
    for(int i = 0; i < rozmiar_1; i++) {
        for(int j = 0; j < rozmiar_2; j++)
            cout << b[i][j] * n << " ";
        cout << endl;
    }
    cout << endl;
}

//  Zamiana wiersza z kolumna, wyswietlenie
void transponowanie(double** a, double** b) {
    cout << "A^T\n\n";
    for (int i = 0; i < rozmiar_2; i++) {
        for (int j = 0; j < rozmiar_1; j++)
            cout << a[j][i] << " ";
        cout << endl;
    }
    cout << endl;
    cout << "B^T\n\n";
    for (int i = 0; i < rozmiar_2; i++) {
        for (int j = 0; j < rozmiar_1; j++)
            cout << b[j][i] << " ";
        cout << endl;
    }
    cout << endl;
}