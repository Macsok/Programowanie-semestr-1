#include <iostream>
#include <cmath>
using namespace std;

void zad1();
int potega(int n, int m);
void zad2();
int algEuklidesa(int, int);
void zad3();
int funkcja(int n);
void zad4();
bool czy_pierwsza(int n);
int zad5();
void funkcja_kwadratowa(float, float, float);

int main() {
    int odp;
    do {
        cout << "-----------------------------------------\n";
        cout << "Wybierz jedna z opcji (numer):\n\n";
        cout << "1    zad.1, potega(m^n)\n";
        cout << "2    zad.2, NWD(a, b)\n";
        cout << "3    zad.3, rekurencja(n-ty wyraz ciagu a(n))\n";
        cout << "4    zad.4, suma pierwszych 10 liczb\n";
        cout << "5    zad.5, f. kwadratowa\n";
        cout << "0    Wyjscie\n";
        cin >> odp;
        cout << "-----------------------------------------\n";
        switch (odp) {
        case 1:
            zad1();
            break;
        case 2:
            zad2();
            break;
        case 3:
            zad3();
            break;
        case 4:
            zad4();
            break;
        case 5:
            zad5();
            break;
        default:
            break;
        }
        cout << endl;
    }   while(odp != 0);
    return 0;
}

void zad1() {
    int a, b;

    //  Wczytanie liczb nieujemnych
    do {
        do {
            cout << "Podaj pierwsza liczbe (>0): ";
            cin >> a;
            cout << "Podaj druga liczbe (>0): ";
            cin >> b;
        }   while(a <= 0 && b <= 0);
    }   while (a < 0 || b < 0);

    cout << a << "^" << b << " = " << potega(a, b);
}

// Zwraca wartosc n^m (gdzie n,m >= 0)
int potega(int n, int m) {
    return pow(n, m);
}

void zad2() {
    int a, b;

    //  Wczytanie nieujemnych liczb calkowitcyh
    do {
        cout << "Podaj pierwsza liczbe: ";
        cin >> a;
        cout << "Podaj druga liczbe: ";
        cin >> b;
    }   while(a <= 0 || b <= 0);

    cout << "NWD(" << a << "; " << b << ") = " << algEuklidesa(a, b);
}

//  Najwiekszy wspolny dzielnik a, b nalezacych do C
int algEuklidesa(int a, int b) {
    while(a != b) {
        if(a > b) a = a - b;
        else b = b - a;
    }
    return a;
}

void zad3() {
    int a, b;

    //  Wczytanie nieujemnej liczby
    do {
        std::cout << "Podaj liczbe: ";
        std::cin >> a;
    }   while( a < 0 );

    std::cout << a << " element ciagu wynosi " << funkcja(a);
}

//  Funkcja rekurencyjna
int funkcja(int n) {
    if(n == 0) return 1;
    else return 2 * funkcja(n - 1) + 5;
}

void zad4() {
    int t[10];
    int i;

    //  Wczytanie 10 liczb
    std::cout << "Podaj 10 liczb\n";
    for(i = 0; i < 10; i++) {
        std::cout << i + 1 << ": ";
        std::cin >> t[i];
    }

    //  Zsumowanie liczb pierwszych
    int suma = 0;
    for(i = 0; i < 10; i++)
        if(czy_pierwsza(t[i])) suma += t[i];
    std::cout << "Suma wynosi: " << suma;

}

//  Zwraca 1 dla liczb pierwszych, 0 dla zlozonych
bool czy_pierwsza(int n) {
    if(n <= 1) return 0;
    for(int  i = 2; i <= sqrt(n); i++) {
        if(n % i == 0) return 0;
    }
    return 1;
}

int zad5() {
    long t[3];

    for(int i = 2; i >= 0; i--) {
        cout << "Podaj wspolczynnik x^" << i << ": ";
        cin >> t[i];
    }

    //  Wykluczenie funkcji liniowych
    if(t[2] == 0){
        cout << "wspolczynnik (a)x^2 nie moze byc zerem";
        return 0;
    }

    funkcja_kwadratowa(t[2], t[1], t[0]);
    return 0;
}

//  Wyswietlenie rozwiazan f. kwadratowej
void funkcja_kwadratowa(float a, float b, float c) {

    //  Wyswietlenie wzoru funckji
    cout << "Funkcja postaci: (" << a << ")x^2";
    if(b != 0) cout << " + (" << b << ")x";
    if(c != 0) cout << " + (" << c << ")";
    cout << endl;

    float delta;
    float x1, x2;
    //  Wyliczenie delty
    delta = (b * b) - (4 * a * c);
    float p_delta = sqrt(delta);

    //  Rozdzielenie przypadkow wzgledem delty
    if(delta < 0) cout << "nie ma miejsc zerowych";
    else if(delta == 0) {
        x1 = (-b) / (2 * a);
        cout << "ma jedno miejscce zerowe: x = " << x1;
    }
    else {
        x1 = ((-b) + p_delta) / (2 * a);
        x2 = ((-b) - p_delta) / (2 * a);
        cout << "ma dwa miejsca zerowe: x = " << x1 << " i x = " << x2;
    }
    cout << endl << "*z dokladnoscia do 6 miejsc po przecinku";
}
