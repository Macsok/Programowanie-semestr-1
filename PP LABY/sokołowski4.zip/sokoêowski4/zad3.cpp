#include <iostream>

int funkcja(int n);

int main() {
    int a, b;

    //  Wczytanie nieujemnej liczby
    do {
        std::cout << "Podaj liczbe: ";
        std::cin >> a;
    }   while( a < 0 );

    std::cout << a << " element ciagu wynosi " << funkcja(a);
    return 0;
}

//  Funkcja rekurencyjna
int funkcja(int n) {
    if(n == 0) return 1;
    else return 2 * funkcja(n - 1) + 5;
}
