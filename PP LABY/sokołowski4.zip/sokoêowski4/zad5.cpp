#include <iostream>
#include <cmath>
using namespace std;

void funkcja_kwadratowa(float, float, float);

int main() {
    long t[3];

    for(int i = 2; i >= 0; i--) {
        cout << "Podaj wspolczynnik x^" << i << ": ";
        cin >> t[i];
    }

    //  Wykluczenie funkcji liniowych
    if(t[2] == 0){
        cout << "wspolczynnik (a)x^2 nie moze byc zerem";
        return 0;
    }

    funkcja_kwadratowa(t[2], t[1], t[0]);
    return 0;
}

//  Wyswietlenie rozwiazan f. kwadratowej
void funkcja_kwadratowa(float a, float b, float c) {

    //  Wyswietlenie wzoru funckji
    cout << "Funkcja postaci: (" << a << ")x^2";
    if(b != 0) cout << " + (" << b << ")x";
    if(c != 0) cout << " + (" << c << ")";
    cout << endl;

    float delta;
    float x1, x2;
    //  Wyliczenie delty
    delta = (b * b) - (4 * a * c);
    float p_delta = sqrt(delta);

    //  Rozdzielenie przypadkow wzgledem delty
    if(delta < 0) cout << "nie ma miejsc zerowych";
    else if(delta == 0) {
        x1 = (-b) / (2 * a);
        cout << "ma jedno miejscce zerowe: x = " << x1;
    }
    else {
        x1 = ((-b) + p_delta) / (2 * a);
        x2 = ((-b) - p_delta) / (2 * a);
        cout << "ma dwa miejsca zerowe: x = " << x1 << " i x = " << x2;
    }
    cout << endl << "*z dokladnoscia do 6 miejsc po przecinku";
}
