#include <iostream>

int algEuklidesa(int, int);

int main() {
    int a, b;

    //  Wczytanie nieujemnych liczb calkowitcyh
    do {
        std::cout << "Podaj pierwsza liczbe: ";
        std::cin >> a;
        std::cout << "Podaj druga liczbe: ";
        std::cin >> b;
    }   while(a <= 0 || b <= 0);

    std::cout << "NWD(" << a << "; " << b << ") = " << algEuklidesa(a, b);
    return 0;
}

//  Najwiekszy wspolny dzielnik a, b nalezacych do C
int algEuklidesa(int a, int b) {
    while(a != b) {
        if(a > b) a = a - b;
        else b = b - a;
    }
    return a;
}
