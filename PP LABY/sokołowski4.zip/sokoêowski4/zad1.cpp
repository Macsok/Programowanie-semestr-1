#include <iostream>
#include <cmath>
using namespace std;

int potega(int n, int m);

int main() {
    int a, b;

    //  Wczytanie liczb nieujemnych
    do {
        do {
            cout << "Podaj pierwsza liczbe: ";
            cin >> a;
            cout << "Podaj druga liczbe: ";
            cin >> b;
        }   while(a <= 0 && b <= 0);
    }   while (a < 0 || b < 0);

    cout << a << "^" << b << " = " << potega(a, b);
    return 0;
}

// Zwraca wartosc n^m (gdzie n,m >= 0)
int potega(int n, int m) {
    return pow(n, m);
}
