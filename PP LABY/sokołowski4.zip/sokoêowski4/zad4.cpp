#include <iostream>
#include <cmath>

bool czy_pierwsza(int n);
int main() {
    int t[10];
    int i;

    //  Wczytanie 10 liczb
    std::cout << "Podaj 10 liczb\n";
    for(i = 0; i < 10; i++) {
        std::cout << i + 1 << ": ";
        std::cin >> t[i];
    }

    //  Zsumowanie liczb pierwszych
    int suma = 0;
    for(i = 0; i < 10; i++)
        if(czy_pierwsza(t[i])) suma += t[i];
    std::cout << "Suma wynosi: " << suma;

    return 0;
}

//  Zwraca 1 dla liczb pierwszych, 0 dla zlozonych
bool czy_pierwsza(int n) {
    if(n <= 1) return 0;
    for(int  i = 2; i <= sqrt(n); i++) {
        if(n % i == 0) return 0;
    }
    return 1;
}
