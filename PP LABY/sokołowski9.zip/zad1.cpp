#include <iostream>
using namespace std;

struct zespolone {
        double im;
        double re;
    };

//  Dodawanie a + b
zespolone dodawanie(zespolone a, zespolone b) {
    zespolone p;
    p.im = a.im + b.im;
    p.re = a.re + b.re;
    return p;
}

//  Odejmowanie a - b
zespolone odejmowanie(zespolone a, zespolone b) {
    zespolone p;
    p.re = a.re - b.re;
    p.im = a.im - b.im;
    return p;
}

//  Mnozenie a * b (a +bi)(c + di) = a * b + a *di + b * ci - bd = ab - bd + (ad + cb)i
zespolone mnozenie(zespolone a, zespolone b) {
    zespolone p;
    p.im = (a.re * b.im) + (a.im * b.re);
    p.re = (a.re * a.im) - (b.re * b.im);
    return p;
}

int main() {
    //  Inicjalizacja liczb zepolonych
    zespolone a, b, c;

    //  Menu
    int d;
    do {
        cout << "1 wprowadz liczby\n2 dodawanie\n3 odejmowanie\n4 mnozenie\n0 wyjscie\n";
        cin >> d;
        switch (d) {
        case 1:
            cout << "Re(a) = ";
            cin >> a.re;
            cout << "Im(a) = ";
            cin >> a.im;
            cout << "Re(b) = ";
            cin >> b.re;
            cout << "Im(b) = ";
            cin >> b.im;
            break;
        case 2:
            c = dodawanie(a, b);
            cout << "a + b = " << c.re << " + " << c.im << "i";
            break;
        case 3:
            c = odejmowanie(a, b);
            cout << "a - b = " << c.re << " + " << c.im << "i";
            break;
        case 4:
            c = mnozenie(a, b);
            cout << "a * b = " << c.re << " + " << c.im << "i";
            break;
        default:
            d = 0;
            break;
        }
        cout << endl;
    } while(d);
    return 0;
}
