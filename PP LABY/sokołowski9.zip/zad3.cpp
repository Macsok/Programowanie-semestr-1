#include <iostream>
#include <string>
#include <vector>
using namespace std;

//	Struktura samochodu
struct car {
	string marka;
	string model;
	float pojemnosc;
	float predkosc;
};

//	ile aut maksymalnie
const int N = 4;

car dodaj_pojazd();
void wyswietl(car pojazd);
void srednia_suma(vector<car> auta, int ile);

int main() {
	int i, dec, ile = 0, suma;
	string s;
	vector<car> *auta = new vector<car>;

	//	Menu
	do {
		cout << "---------------------------------------------\n";
		cout << "1 wprowadzenie samochodu\n2 wyswietlenie samochodu\n3 usuniecie samochodu\n4 suma pojemnosci/srednia predkosc\n0 wyjscie\n";
		cin >> dec;
		switch (dec) {
		case 1:
			if (ile < N) {
				auta->emplace_back(dodaj_pojazd());
				ile++;
			}
			else cout << "Baza pelna";
			break;
		case 2:
			cout << "Ktory pojazd wyswietlic? ";
			cin >> i;
			if (i >= ile) cout << "Brak elementu";
			else wyswietl(auta->at(i));
			break;
		case 3:
			//	Usuwanie elementu
			cout << "Ktory rejestr usunac? ";
			cin >> i;
			auta->erase(auta->begin() + i);
			ile--;
			break;
		case 4:
			if (ile) srednia_suma(*auta, ile);
			break;
		default:
			dec = 0;
			break;
		}
		cout << endl;
	} while (dec);
	//	Zwalnianie pamieci
	delete auta;
	return 0;
}

//	Nowy rejestr
car dodaj_pojazd() {
	//	Deklaracja zmiennej
	car nowy;
	cout << "Marka: ";
	cin >> nowy.marka;
	cout << "Model: ";
	cin >> nowy.model;
	cout << "Pojemnosc: ";
	cin >> nowy.pojemnosc;
	cout << "Predkosc maks.: ";
	cin >> nowy.predkosc;
	return nowy;
}

//	Wyswietlenie rejestru
void wyswietl(car pojazd) {
	cout << endl << pojazd.marka << " - " << pojazd.model << " - " << pojazd.pojemnosc << " - " << pojazd.predkosc << endl;
}

void srednia_suma(vector<car> auta, int ile) {
	int i, suma = 0;
	//	Sumowanie pojemnosci
	for (i = 0; i < ile; i++) suma += auta[i].pojemnosc;
	cout << "Suma pojemnosci: " << suma;
	suma = 0;
	//	Sumowanie predkosci
	for (i = 0; i < ile; i++) suma += auta[i].predkosc;
	cout << "\nSrednia predkosc: " << suma / ile;
}