#include <iostream>
#include <string>
using namespace std;

//	Deklaracja struktury
struct car {
	string marka;
	string model;
	float pojemnosc;
	float predkosc;
};

//	ile aut
const int N = 4;

car* dodaj_pojazd();
void wyswietl(car pojazd);
void srednia_suma(car auta[], int ile);

int main() {
	int i, dec, ile = 0, suma;
	string s;
	car* auta = new car[N];

	//	Menu
	do {
		cout << "---------------------------------------------\n";
		cout << "1 wprowadzenie samochodu\n2 wyswietlenie samochodu\n3 usuniecie samochodu\n4 suma pojemnosci/srednia predkosc\n0 wyjscie\n";
		cin >> dec;
		switch (dec) {
		case 1:
			if (ile < N) {
				auta[ile] = *dodaj_pojazd();
				ile++;
			}
			else cout << "Baza pelna";
			break;
		case 2:
			cout << "Ktory pojazd wyswietlic? ";
			cin >> i;
			if (i >= ile) cout << "Brak elementu";
			else wyswietl(auta[i]);
			break;
		case 3:
			cout << "Ktory rejestr usunac? ";
			cin >> i;
			//	Zsuwanie tablicy
			for (i; i < N - 1; i++) auta[i] = auta[i + 1];
			ile--;
			break;
		case 4:
			if(ile) srednia_suma(auta, ile);
			break;
		default:
			dec = 0;
			break;
		}
		cout << endl;
	} while (dec);
	//	Zwalnianie pamieci
	delete[] auta;
	return 0;
}

//	Nowy rejestr
car* dodaj_pojazd() {
	//	Deklaracja zmiennej
	car* nowy = new car;
	cout << "Marka: ";
	cin >> nowy->marka;
	cout << "Model: ";
	cin >> nowy->model;
	cout << "Pojemnosc: ";
	cin >> nowy->pojemnosc;
	cout << "Predkosc maks.: ";
	cin >> nowy->predkosc;
	return nowy;
}

//	Wyswietlenie rejestru
void wyswietl(car pojazd) {
	cout << endl << pojazd.marka << " - " << pojazd.model << " - " << pojazd.pojemnosc << " - " << pojazd.predkosc << endl;
}

void srednia_suma(car auta[], int ile) {
	int i, suma = 0;
	//	Sumowanie pojemnosci
	for (i = 0; i < ile; i++) suma += auta[i].pojemnosc;
	cout << "Suma pojemnosci: " << suma;
	suma = 0;
	//	Sumowanie predkosci
	for (i = 0; i < ile; i++) suma += auta[i].predkosc;
	cout << "\nSrednia predkosc: " << suma / ile;
}