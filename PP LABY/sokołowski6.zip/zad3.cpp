#include <iostream>
#include <string>
using namespace std;

string godzina(int godz, int minuta, int sek);

int main() {
    int godz, minuta, sek;
    cout << "G: ";
    cin >> godz;
    cout << "M: ";
    cin >> minuta;
    cout << "S: ";
    cin >> sek;

    cout << godzina(godz, minuta, sek);
    return 0;
}

string godzina(int godz, int minuta, int sek) {
    return to_string(godz) + ':' + to_string(minuta) + ':' + to_string(sek);
}
