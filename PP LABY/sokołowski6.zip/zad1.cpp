#include <iostream>
using namespace std;

void wyswietl_ASCII(char tab[]);

int main() {
    char imie_nazwisko[50];
    char ulica[50];
    char numer_domu[50];
    char ocena[2];
    char staz[10];

    cout << "Podaj swoje imie i nazwisko: ";
    cin.getline(imie_nazwisko, 50);
    cout << "Podaj nazwe ulicy, przy ktorej mieszkasz: ";
    cin.getline(ulica, 50);
    cout << "Podaj numer domu: ";
    cin.getline(numer_domu, 50);
    cout << "Na ile oceniasz swoje umiejetnosci programowania w skali <2, 5>: ";
    cin.getline(ocena, 2);
    cout << "Jaki masz staz programistyczny: ";
    cin.getline(staz, 10);

    cout << endl;
    cout << "PROGRAMISTA " << imie_nazwisko << "; ASCII: ";
    wyswietl_ASCII(imie_nazwisko);
    cout << endl;
    cout << "Adres: " << ulica << " " << numer_domu << endl;
    cout << "Ocena z podstaw programowania: " << (char)((int)ocena[0] - 1) << endl;
    cout << "staz programisty: " << staz << " dni";
    return 0;
}

void wyswietl_ASCII(char tab[]) {
    int i = 0;
    while(tab[i] != 0) {
            cout << (int)tab[i];
            i++;
    }
}
