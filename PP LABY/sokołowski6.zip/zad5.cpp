#include <iostream>
using namespace std;

void na_male(char arr[]) {
	int i = 0;
	while (arr[i]) {
		if (arr[i] > 64 && arr[i] < 91) arr[i] += 32;
		i++;
	}
}
void histogram(char _ch[]);

int main() {
	char tekst[100];
	cout << "Wprowadz tekst: ";
	cin.getline(tekst, 100);
	histogram(tekst);
	return 0;
}

void histogram(char _ch[]) {
	//	konwersja na lowercase
	na_male(_ch);
	int buff[26] = {}, i = 0;
	while (_ch[i]) {
		if (_ch[i] >= 97 && _ch[i] <= 122)
			buff[_ch[i] - 97]++;
		i++;
	}
	for (i = 0; i < 26; i++)
		if (buff[i]) {
			cout << char(i + 97) << " ";
			for (int n = 0; n < buff[i]; n++)
				cout << "#";
			cout << endl;
		}
}