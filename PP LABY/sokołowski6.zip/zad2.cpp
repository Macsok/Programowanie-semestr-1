#include <iostream>
#include <string>
using namespace std;

//float sr_predkosc(char one[], char two[], char three[]);

int main() {
    int i;
    char marka[3][50];
    char model[3][50];
    string pojemnosc[3];
    string pr_max[3];

    for(i = 0; i < 3; i ++) {
        cout << "Samochod " << i + 1 << ":" << endl;
        cout << "Marka: ";
        cin.getline(marka[i], 50);
        cout << "Model: ";
        cin.getline(model[i], 50);
        cout << "Pojemnosc: ";
        getline(cin, pojemnosc[i]);
        cout << "Predkosc maksymalna: ";
        getline(cin, pr_max[i]);
    }

    //  Wypisanie
    for(i = 0; i < 3; i ++)
        cout << marka[i] << " - " << model[i] << " - " << pojemnosc[i] << " - " << pr_max[i] << endl;

    cout << "Suma pojemnosci silnikow wprowadzonych samochodow: " << stof(pojemnosc[0]) + stof(pojemnosc[1]) + stof(pojemnosc[2]) << endl;
    cout << "Srednia predkosc maksymalna wynosi: " << ( stof(pr_max[0]) + stof(pr_max[1]) + stof(pr_max[2]) ) / 3 << "km/h";
    return 0;
}
