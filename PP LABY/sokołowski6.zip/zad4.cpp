#include <iostream>
#include <string>
#include <windows.h>
using namespace std;

int dlugosc(char tab[]);
void odwroc(char tab[]);
//	n = 1 zamiana na duze, n = 0 zamiana na male
void caps(char arr[], int n);

int main() {
	char tekst[50];
	short int option;
	bool d = true;
	string buff;
	//	Menu
	do {
		system("CLS");
		cout << "1 Wprowadz tekst\n2 Wyswietl\n3 Liczba znakow\n4 Odwroc\n5 Zmiana wielkosci\n6 Wyjscie\n";
		cin >> option;
		cin.ignore();
		switch (option) {
		case 1:
			cout << "Tekst: ";
			cin.getline(tekst, 50);
			break;
		case 2:
			cout << "Tekst: " << tekst << endl;;
			break;
		case 3:
			cout << "Liczba znakow: " << dlugosc(tekst) << endl;;
			break;
		case 4:
			odwroc(tekst);
			cout << "Odwrocono: " << tekst << endl;
			break;
		case 5:
			cout << "Zamien na:\n0 male\n1 DUZE\n";
			cin >> option;
			caps(tekst, option);
			option = 5;
			cout << "Zamieniono (" << tekst << ")\n";
			break;
		default:
			d = false;
			break;
		}
		//	pauza
		cout << "\nKontynuuj (enter)";
		getline(cin, buff);
	} while (d);
	return 0;
}

int dlugosc(char tab[]) {
	int i = 0;
	while (tab[i]) i++;
	return i;
}

void odwroc(char tab[]) {
	int j = dlugosc(tab) - 1;
	char buff;
	for (int i = 0; i < dlugosc(tab) / 2; i++) {
		buff = tab[i];
		tab[i] = tab[j];
		tab[j] = buff;
		j--;
	}
}

void caps(char arr[], int n) {
	int i = 0;
	if (n == 1)
		while (arr[i]) {
			if (arr[i] > 96 && arr[i] < 123) arr[i] -= 32;
			i++;
		}
	if (n == 0)
		while (arr[i]) {
			if (arr[i] > 64 && arr[i] < 91) arr[i] += 32;
			i++;
		}
}