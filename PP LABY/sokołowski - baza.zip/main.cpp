#include "headers.hpp"

int main() {
	menu();
	return 0;
}